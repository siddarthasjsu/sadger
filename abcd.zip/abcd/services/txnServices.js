const txnModel = require('../model/Transaction');
const userAccountModel = require('../model/UserAccount');
const recurringTxnModel = require('../model/RecurringTransaction');
const userModel = require('../model/User');
var Sequelize = require("sequelize");
const Op = Sequelize.Op

module.exports.debitFrom = function(txn){
    return new Promise(function(resolve,reject){
        txn["type_of_transcation"] = "Debit";
        var from = txn.from_acct_id;
        userAccountModel.findOne({ where : { "account_num" : from , "user_id" : txn.from_user_id,}})
        .then( fromAcct => {
            if(fromAcct == null){
                resolve({ message : " Unauthorized or Invalid From acct"})
            } else {
            userAccountModel.findOne({ where : {  "account_num" : txn.to_acct_id}})
            .then( toAcct => {
                if(toAcct == null){
                    resolve({ message : "Invalid To acct"})
                }else {
                    var curbal= parseFloat(fromAcct.current_bal);
                    userAccountModel.findOne({
                        where : { "account_num" : txn.from_acct_id, 'current_bal' : {[Op.gte] : txn.amount}  }
                    }).then( acct => {
                        if(acct == null){
                            resolve({message : "Not enough balance"})
                        } else {
                        userAccountModel.update({
                            'current_bal': curbal - txn.amount
                        },{
                            where : { "account_num" : txn.from_acct_id, 'current_bal' : {[Op.gte] : txn.amount}  }
                        }).then(res => {
                            txnModel.create(txn)
                            .then( txn => {
                                resolve(txn);
                            })
                        })
                    }
                    }) 
                }
            })
        }
        })
        .catch(err => {
            reject(err);
        })
    })
}

module.exports.debitFee = function(txn){
    return new Promise(function(resolve,reject){
        var from = txn.from_acct_id;
        userAccountModel.findOne({ where : { "account_num" : from , "user_id" : txn.from_user_id,}})
        .then( fromAcct => {
            if(fromAcct == null){
                resolve({ message : " Unauthorized or Invalid From acct"})
            } else {
                var curbal= parseFloat(fromAcct.current_bal);
                userAccountModel.findOne({
                    where : { "account_num" : txn.from_acct_id, 'current_bal' : {[Op.gte] : txn.amount}  }
                })
                .then( acct => {
                    if(acct == null){
                        resolve({message : "Not enough balance"})
                    } else {
                        userAccountModel.update({
                            'current_bal': curbal - txn.amount
                        },{
                            where : { "account_num" : txn.from_acct_id, 'current_bal' : {[Op.gte] : txn.amount}  }
                        }).then(res => {
                            txnModel.create(txn)
                            .then( txn => {
                                resolve(txn);
                            })
                        })
                    }
                })
            }
            })
        .catch(err => {
        reject(err);
        })
    })
}

module.exports.creditTo = function(txn){
    return new Promise(function(resolve,reject){
        txn["type_of_transcation"] = "Credit";
        userAccountModel.findOne({ where : {  "account_num" : txn.to_acct_id}})
            .then(result => {
                txn["from_user_id"] = result.dataValues.user_id
                userAccountModel.findOne({ where : {  "account_num" : txn.to_acct_id}})
                    .then( acct => {
                        if(acct == null){
                            resolve({ message : "Invalid To acct"})
                        } else {
                        var curbal= parseFloat(acct.current_bal);
                        userAccountModel.update({
                            'current_bal': curbal + txn.amount
                        },{
                            where : { "account_num" : txn.to_acct_id }
                        }).then(res => {
                            txnModel.create(txn)
                            .then( txn => {
                                resolve(txn);
                            })
                        })
                    }
            })
        }).catch(err => {
            console.log("error msg ",err.message);
            reject(err);
        })
    })
}

module.exports.getTxns = function(acctId,from_user_id){
    return new Promise(function(resolve,reject){
        userAccountModel.findOne({ where : {  "account_num" : acctId ,  "user_id" : from_user_id}})
        .then( res => {
            if(res==null){
                resolve({ message : " Unauthorized or Invalid acct number"})
            } else {
                txnModel.findAll({where : Sequelize.or({ "from_user_id" : from_user_id})})
                .then( txns => {
                    recurringTxnModel.findAll({where : Sequelize.or({"from_acct_id" :acctId}, { "to_acct_id" : acctId})})
                    .then(recurtxns => {
                        let res = txns.concat(recurtxns);
                        resolve(res);
                    })
                })
            }   
        })
        .catch( err => {
            reject(err);
        })
    })
}

module.exports.getTxnsByFilter = function(filters){
    return new Promise(function(resolve,reject){
        userAccountModel.findOne({ where : {  "account_num" : filters.fromAcctId ,  "user_id" : filters.from_user_id}})
        .then( res => {
            if(res==null){
                resolve({ message : " Unauthorized or Invalid acct number"})
            } else {
                const filter = {};
                if(filters.from_acct_id!=null && filters.from_acct_id!='') filter["from_acct_id"] = filters.fromAcctId;
                if(filters.type!=null && filters.type!='') filter["type_of_transcation"] = filters.type;
                if(filters.toAcctId!=null && filters.toAcctId!='') filter["to_acct_id"] = filters.toAcctId;
                if(filters.amount!=null && filters.amount!='') filter["amount"] = filters.amount;
                if(filters.descr!=null && filters.descr!='') filter["description"] = { [Op.like] : filters.descr};
                if(filters.after!=null && filters.after!='') filter["created_on"] = { [Op.gte] : filters.after};
                if(filters.before!=null && filters.before!='') filter["created_on"] = { [Op.lte] : filters.before};
                txnModel.findAll({where : filter})
                .then(txns => {
                    resolve(txns);
                })
            }
        })
        .catch(err => {
            reject(err);
        })
    })
}

module.exports.setupRecurringTxns = function(txn) {
    return new Promise(function(resolve,reject){
        var valid = validateRecurringTxn(txn)
        if(!valid.error) {
        userAccountModel.findOne({ where: { "account_num" : txn.from_acct_id, "user_id" : txn.from_user_id }})
        .then( res => {
            if(res==null){
                resolve({ message : " Unauthorized or Invalid From account"})
            } else {
            userAccountModel.findOne({ where: { "account_num" : txn.to_acct_id }})
            .then( resp => {
                if(resp==null){
                    resolve({ message : "Invalid To account"})
                } else {
                recurringTxnModel.create(txn)
                .then( results => {
                    resolve(results);
                })
            }
            })
        }
        })
        .catch(err => {
            reject(err);
        })
    } else {
        resolve({message : valid.message})
    }
    })
}

module.exports.setupRecurringBillPayments = function(txn) {
    return new Promise(function(resolve,reject){
        var valid = validateRecurringTxn(txn)
        if(!valid.error) {
        userAccountModel.findOne({ where: { "account_num" : txn.from_acct_id, "user_id" : txn.from_user_id }})
        .then( res => {
            if(res==null){
                resolve({ message : " Unauthorized or Invalid From account"})
            } else {
            userAccountModel.findOne({ where: { "account_num" : txn.to_acct_id }})
            .then( resp => {
                if(resp==null){
                    resolve({ message : "Invalid To account"})
                } else {
                recurringTxnModel.create(txn)
                .then( results => {
                    resolve(results);
                })
            }
            })
        }
        })
        .catch(err => {
            reject(err);
        })
    } else {
        resolve({message : valid.message})
    }
    })
}

module.exports.addManualRefund = function(userId,txn){
    return new Promise(function(resolve,reject){
    userModel.findOne({ where : { id : userId , type_of_user : "admin"}})
    .then( res => {
        if(res==null){
            resolve({ message : "Unauthorized"})
        }
            else {
                txn["from_acct_id"] = ""
                userAccountModel.findOne({ where : {  "account_num" : txn.toAcctId}})
                .then( acct => {
                    if(acct == null){
                        resolve({ message : "Invalid To acct"})
                    }
                    txn["from_user_id"] = userId;
                    txn["to_acct_id"] = txn.toAcctId;
                    txn["type_of_transcation"] = "Credit";
                    var curbal= parseFloat(acct.current_bal);
                    userAccountModel.update({
                        'current_bal': curbal + txn.amount
                    },{
                        where : { "account_num" : txn.toAcctId }
                    }).then(res => {
                        txnModel.create(txn)
                        .then( txn => {
                            resolve(txn);
                        })
                    })
                })
            }
        })
    .catch(err => {
        reject(err);
    })
    })
}

module.exports.setupRecurringBillPayments = function(txn) {
    return new Promise(function(resolve,reject){
        console.log("Reached here");
        var valid = validateRecurringTxn(txn)
        console.log("valid is ",valid)
        if(!valid.error) {
        userAccountModel.findOne({ where: { "account_num" : txn.from_acct_id, "user_id" : txn.from_user_id }})
        .then( res => {
            if(res[0]==0){
                resolve({ message : " Unauthorized or Invalid From account"})
            }
                recurringTxnModel.create(txn)
                .then( results => {
                    resolve(results);
                })
            })
        .catch(err => {
            reject(err);
        })
    } else {
        resolve({message : valid.message})
    }
    })
}

const months = {
    "January" : 31,
    "February" : 28,
    "March" : 31,
    "April" : 30,
    "May" : 31,
    "June" : 30,
    "July" : 31,
    "August" : 31,
    "September" : 30,
    "October" : 31,
    "November" : 30,
    "December" : 31

}

var validateRecurringTxn = function(txn){
    if(txn.period!="Yearly" && txn.period!="Monthly"){
        return { error : true , message : "Specify period as Yearly or Monthly"};
    }
    if(txn.period=="Yearly" && !txn.month in months){
        return { error : true , message :"Invalid month. Please specify full month name"};
    }
    if(txn.period=="Yearly" && (txn.month==null || txn.month=="") ){
        return { error : true , message :"Invalid month. Please specify full month name"};
    }
    if(txn.total_transactions<=1 || txn.total_transactions >=25){
        return { error : true , message :"Total transactions should be between 2 and 25"};
    }
    if(txn.period=="Monthly" && (txn.date<=1 || txn.date>=28)){
        return { error : true , message :"Date should be between 1 and 28"};
    }
    if(txn.period=="Yearly" && months[txn.month]<txn.date ){
        return { error : true , message :"Only "+months[txn.month]+" days in "+txn.month};
    }
    return {error:false}
}

module.exports.getRecurringTransfers = function(acctId,from_user_id) {
    return new Promise(function(resolve,reject){
        recurringTxnModel.findOne({ where : { from_acct_id : acctId , "from_user_id" : from_user_id, type_of_transcation : { [Op.not] : "Fees"}}})
        .then( res => {
            if(res==null){
                resolve({ message : "Invalid account id"})
            }
            recurringTxnModel.findAll({ where : { from_acct_id : acctId , "from_user_id" : from_user_id, type_of_transcation : { [Op.not] : "Fees"}}})
            .then( txns => {
                resolve(txns);
            })
        })
        .catch( err => {
            reject(err);
        })
    })
}

module.exports.getRecurringBillPayments = function(acctId,from_user_id) {
    return new Promise(function(resolve,reject){
        recurringTxnModel.findOne({ where : { from_acct_id : acctId , "from_user_id" : from_user_id, type_of_transcation :  { [Op.not] : "Debit"}}})
        .then( res => {
            if(res==null){
                resolve({ message : "Invalid account id"})
            }
            recurringTxnModel.findAll({ where : { from_acct_id : acctId , "from_user_id" : from_user_id,type_of_transcation :  { [Op.not] : "Debit"}}})
            .then( txns => {
                resolve(txns);
            })
        })
        .catch( err => {
            reject(err);
        })
    })
}

module.exports.updateAcctIdTxnModel = function(oldAcctId,newAcctId)  {
    console.log(oldAcctId, newAcctId)
    return new Promise((resolve, reject) => {
        (async() => {
            await txnModel.update( { from_acct_id : newAcctId},
                {where :  { from_acct_id  : oldAcctId } })
            await txnModel.update( { to_acct_id : newAcctId},
                {where :  { to_acct_id  : oldAcctId } })
            resolve(true)
        }) ()
    })

}

module.exports.updateAcctIdRecurTxnModel = function(oldAcctId,newAcctId)  {
    return new Promise((resolve, reject) => {
        (async() => {
            await recurringTxnModel.update( { from_acct_id : newAcctId},
                {where :  { from_acct_id  : oldAcctId } })
            await recurringTxnModel.update( { to_acct_id : newAcctId},
                {where :  { to_acct_id  : oldAcctId } })
            resolve(true)
        }) ()
    })

}
