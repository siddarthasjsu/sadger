'use strict'
const express = require('express')
const router = express.Router()
const cors = require('cors')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
var Sequelize = require("sequelize");
const Op = Sequelize.Op

const userModel = require('../model/User');
const userAccountModel = require('../model/UserAccount');
const txnModel = require('../model/Transaction');

const txnService = require('../services/txnServices');

router.use(cors());

process.env.SECRET_KEY = 'secret';
const jwtExpiryInSeconds = 600000

//Registration
exports.addAdmin = (req, res) => {
    try {

        const userData = {
            username: req.body.username,
            email: req.body.email,
            password: req.body.password,
            type_of_user: 'admin',
            phone_num: req.body.phone_num,
            created_by_user_id: req.payLoad.id,
        }

        userModel.findOne({
            where: {
                //email: req.body.email
                [Op.or]: [{email: req.body.email}, {phone_num: req.body.phone_num}]
            }
        })
            .then(user => {
                if (!user) {
                    bcrypt.hash(req.body.password, 10, (err, hash) => {
                        userData.password = hash
                        userModel.create(userData)
                            .then(user => {
                                return res.send({ error: false, message: "Congrats, Admin has been Successfully Created" })
                            })
                            .catch(err => {
                                //res.end('error: ' + err)
                                return res.status(500).send({ error: true, message: err });
                            })
                    })
                } else {
                    return res.status(400).send({ error: true, message: "Email Id or Phone Number already exists..." });
                }
            })
            .catch(err => {
                return res.status(500).send({ error: true, message: err })
            })



    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
};

exports.logout = (req, res) => {
    
        return res.status(200).send({ error: false, message: "Logged Out Successfully...." });
    
};


//Registration
exports.addUser = (req, res) => {
    try {

        const userData = {
            username: req.body.username,
            email: req.body.email,
            password: req.body.password,
            type_of_user: 'user',
            phone_num: req.body.phone_num,
            created_by_user_id: req.payLoad.id,
        }


        userModel.findOne({
            where: {
                //email: req.body.email
                [Op.or]: [{email: req.body.email}, {phone_num: req.body.phone_num}]
            }
        })
            .then(user => {
                if (!user) {
                    bcrypt.hash(req.body.password, 10, (err, hash) => {
                        userData.password = hash
                        userModel.create(userData)
                            .then(user => { //console.log("user..",user);
                                return res.send({ error: false, message: `Congrats, User has been Successfully Created with User Id ${user.dataValues.id}`})
                            })
                            .catch(err => {
                                return res.status(500).send({ error: true, message: err });
                            })
                    })
                } else {
                    return res.status(400).send({ error: true, message: "Email Id or Phone Number already exists..." });
                }
            })
            .catch(err => {
                return res.status(500).send({ error: true, message: err })
            })



    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
};


exports.login = (req, res) => {
    try {
        userModel.findOne({
            where: {
                email: req.body.email
            }
        })
            .then(user => {
                if (user) {
                    if (bcrypt.compareSync(req.body.password, user.password)) {

                        let jwtPayload = { id: user.dataValues.id, first_name: user.dataValues.first_name, last_name: user.dataValues.last_name, type_of_user: user.dataValues.type_of_user }
                        let token = jwt.sign(jwtPayload, process.env.SECRET_KEY, {
                            expiresIn: jwtExpiryInSeconds
                        })

                        
                        res.cookie('token', token, { maxAge: jwtExpiryInSeconds * 100000 });
                        //res.setHeader(200, {'Content-Type': 'application/json'});
                        //res.end(JSON.stringify({error:false,message:"Successfully Logged In..."}));
                        res.send({ error: false, message: "Successfully Logged In...", token: token });
                    }
                    else {
                        return res.status(401).send({ error: true, message: 'Incorrect Username or password...' });
                    }
                } else {
                    return res.status(401).send({ error: true, message: 'User does not exist' });
                }
            })
            .catch(err => {
                return res.status(408).send({ error: true, message: err });
            });
    } catch (e) {
        console.log("Error abc :", e);
        return res.status(408).send({ error: true, message: e });
    }
}

exports.getOwnProfile = (req, res) => {

    userModel.findOne({
        where: {
            id: req.payLoad.id,
            //type_of_user : 'user'
        }
    })
        .then(user => {
            if (user) {
                const userDetails = {
                    id      : user.dataValues.id,
                    username: user.dataValues.username,
                    email: user.dataValues.email,
                    phone_num: user.dataValues.phone_num,
                };

                res.status(200).json({ error: false, message: "User Profile Details...", userDetails: userDetails });

            } else {
                return res.status(400).json({ error: true, message: 'User does not exist' });
            }
        })
        .catch(err => {
            return res.status(401).json({ error: true, message: err.message });
        });

}

//Edit User Profile Details
exports.editOwnProfile = (req, res) => {
    req.body.type_of_user = req.payLoad.type_of_user;

    const userData = {
        username: req.body.username,
        email: req.body.email,
        phone_num: req.body.phone_num,
        updated_by_user_id: req.payLoad.id
    }

    userModel.count({
        where: {
            id: req.payLoad.id,
            //type_of_user : 'user'
        }
    })
        .then(c => {
            if (c) {
                userModel.update(userData,
                    {
                        where: { id: req.payLoad.id }
                    })
                    .then(updatedProfile => {

                        return res.status(200).json({ error: false, message: "Data Successfully Updated..." });

                    })
                    .catch(err => {
                        //console.log("Error is ",err);
                        return res.status(500).json({ error: true, message: err.message });
                    });

            } else {
                return res.status(400).json({ error: true, message: 'User does not exist' });
            }
        })
        .catch(err => {
            return res.status(400).json({ error: true, message: err.message });
        });
}

exports.oneTimeTransfer = (req, res) => {

    const txn = {
        from_acct_id : req.body.fromAcctId,
        to_acct_id : req.body.recipient,
        amount : req.body.amt,
        description : req.body.descr,
        from_user_id : req.body.id,
    }
    txnService.debitFrom(txn)
    .then( (result ) => {
        if(result.message==null){
            txnService.creditTo(txn)
            .then( resp => {
                if(resp.message==null)
                res.status(200).json({error: false, message: "Txn successful!", txnDetails : txn});
                else
                res.status(422).json({error: true, message: resp.message, txnDetails : txn});
            })
        }else {
            res.status(423).json({error: true, message: result.message, txnDetails : null});
        }
    })
    .catch( err => {
        res.status(500).json({error: true, message: "Txn Unsuccessful! "+err.message});
    })
}

exports.oneTimeBillPayment = (req, res) => {

    const txn = {
        from_acct_id : req.body.fromAcctId,
        to_acct_id : "",
        amount : req.body.amt,
        description : req.body.descr,
        from_user_id : req.body.id,
        type_of_transcation : "Fees"
    }
    txnService.debitFee(txn)
    .then( (result ) => {
        if(result.message==null)
        res.status(200).json({error: false, message: "Txn successful!", txnDetails : txn});
        else
        res.status(422).json({error: true, message: result.message, txnDetails : null});
    })
    .catch( err => {
        res.status(500).json({error: false, message: "Txn unsuccessful! "+err.message});
    })
}


exports.recurringTransfer = (req,res) => {
    const txn = {
        from_acct_id : req.body.fromAcctId,
        to_acct_id : req.body.recipient,
        amount : req.body.amt,
        description : req.body.descr,
        from_user_id : req.body.id,
        period : req.body.period,
        date : req.body.date,
        time : req.body.time,
        month : req.body.month,
        total_transactions : req.body.numberOfTransfers,
        type_of_transcation : "Debit"
    }
    txnService.setupRecurringTxns(txn)
    .then(resp => {
        if(resp.message==null)
        res.status(200).json({error: false, message: "Setting Up recurring payment!", txnDetails : txn});
        else
        res.status(422).json({error: true, message: resp.message, txnDetails : null});
    })
    .catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.recurringBillPayments = (req,res) => {
    const txn = {
        from_acct_id : req.body.fromAcctId,
        to_acct_id : "",
        amount : req.body.amt,
        description : req.body.descr,
        from_user_id : req.body.id,
        period : req.body.period,
        date : req.body.date,
        time : req.body.time,
        month : req.body.month,
        total_transactions : req.body.numberOfTransfers,
        type_of_transcation : "Fees"
    }
    txnService.setupRecurringBillPayments(txn)
    .then(resp => {
        if(resp.message==null)
        res.status(200).json({error: false, message: "Setting Up recurring payment!", txnDetails : txn});
        else 
        res.status(422).json({error: true, message: resp.message, txnDetails : null });
    })
    .catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.viewAllTxns = (req,res) => {
    const acctId = req.params.acctId;
    const from_user_id = req.params.id;
    txnService.getTxns(acctId,from_user_id)
    .then( txns => {
        if(txns.message==null)
        res.status(200).json({error: false, message: "Fetching transactions!", txnDetails : txns});
        else
        res.status(422).json({error: true, message: txns.message, txnDetails : null});
    }).catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.getTxnsByFilter = (req,res) => {
    const filters = {
        fromAcctId : req.body.fromAcctId,
        before : req.body.before,
        after : req.body.after,
        descr : req.body.descr,
        amount : req.body.amount,
        type : req.body.type,
        toAcctId : req.body.toAcctId,
        from_user_id : req.body.id
    }
    txnService.getTxnsByFilter(filters)
    .then( txns => {
        if(txns.message==null)
        res.status(200).json({error: false, message: "Fetching transactions!", transactions : txns});
        else
        res.status(422).json({error: true, message: txns.message, txnDetails : null});
    }).catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.addManualRefund = (req,res) => {
    const adminId =  req.body.id;
    const txn = {
        toAcctId : req.body.toAcctId,
        amount : req.body.amount,
        description : req.body.descr
    }
    txnService.addManualRefund(adminId,txn)
    .then(resp => {
        if(resp.message==null)
        res.status(200).json({error: false, message: "Setting Up recurring payment!", txnDetails : txn});
        else
        res.status(422).json({error: true, message: resp.message, txnDetails : null});
    })
    .catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.getRecurringTransfers = (req,res) => {
    const acctId = req.params.acctId;
    var from_user_id = req.params.id;
    txnService.getRecurringTransfers(acctId,from_user_id)
    .then( txns => {
        if(txns.message == null)
        res.status(200).json({error: false, message: "Fetching transactions!", txnDetails : txns});
        else
        res.status(422).json({error: true, message: txns.message, txnDetails : null});
    }).catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

exports.getRecurringBillPayments = (req,res) => {
    var from_user_id = req.params.id;
    const acctId = req.params.acctId;
    txnService.getRecurringBillPayments(acctId,from_user_id)
    .then( txns => {
        if(txns.message==null)
        res.status(200).json({error: false, message: "Fetching transactions!", txnDetails : txns});
        else
        res.status(422).json({error: true, message: txns.message, txnDetails : null});
    }).catch( err => {
        res.status(500).json({error: false, message: err.message});
    })
}

