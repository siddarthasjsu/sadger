'use strict'
const express = require('express')
const router = express.Router()
const cors = require('cors')
var Sequelize = require("sequelize");
var randomstring = require("randomstring");
const txnService = require('../services/txnServices');
const userModel = require('../model/User');
const userAccountModel = require('../model/UserAccount');

router.use(cors());

// Get account details
exports.getAccount = async (req, res) => {
    try {
        const user = await userModel.findAll({
            where: {
                id: req.params.userId
            }
        })
        if (user.length == 0) {
            return res.status(400).send("Invalid user ID")
        }

        const accounts = await userAccountModel.findAll({
            attributes: ['account_num', 'type_of_account', 'current_bal', 'created_on', 'created_by_user_id', 'updated_by_user_id'],
            where: {
                user_id: req.params.userId,
                account_status: "Active"
            }
        })
        if (accounts.length == 0) {
            return res.status(204).json()
        }
        return res.status(200).send(accounts);

    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
}


// Create checkings or savings account
exports.addAccount = async (req, res) => {
    try {
        console.log("Narisht..",req.body);
        const adminDetails = await userModel.findOne({
            where: {
                id: req.payLoad.id,
                type_of_user: 'admin'
            }
        })
        if (!adminDetails) {
            return res.send(400).json()
        }

        const userDetails = await userModel.findOne({
            where: {
                id: req.body.userId,
                type_of_user: 'user'
            }
        })
        if (!userDetails) {
            return res.send(400).json()
        }

        const userAccount = await userAccountModel.findOne({
            where: {
                user_id: req.body.userId,
                type_of_account: req.body.type_of_account,
                account_status: 'Active'
            }
        })
        if (userAccount) {
            return res.status(409).send("Account type already exists for user")
        }

        let accNumber = randomstring.generate({
            length: 12,
            charset: 'alphanumeric',
            capitalization: 'uppercase'
        });
        let accountDetails = await userAccountModel.findOne({
            where: {
                account_num: accNumber
            }
        })
        while (accountDetails) {
            accNumber = randomstring.generate({
                length: 12,
                charset: 'alphanumeric',
                capitalization: 'uppercase'
            });
            accountDetails = await userAccountModel.findOne({
                where: {
                    account_num: accNumber
                }
            })
        }

        const newAccount = await userAccountModel.create({
            user_id: req.body.userId,
            account_num: accNumber,
            type_of_account: req.body.type_of_account,
            current_bal: 1000.000,
            created_by_user_id: 1
        })
        return res.status(200).send(newAccount)

    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
}

// Update account number
exports.updateAccount = async (req, res) => {
    try {
        let accountDetails
        const adminDetails = await userModel.findOne({
            where: {
                id: req.payLoad.id,
                type_of_user: 'admin'
            }
        })
        if (!adminDetails) {
            return res.send(400).json()
        }

        if (req.body.newAccNumber != req.body.oldAccNumber) {
            accountDetails = await userAccountModel.findOne({
                where: {
                    account_num: req.body.newAccNumber
                }
            })
            if (accountDetails) {
                return res.status(409).send("Account number already exists")
            }
        }

        accountDetails = await userAccountModel.update(
            {
                account_num: req.body.newAccNumber,
                current_bal: Sequelize.literal('current_bal + ' + req.body.amount),
                updated_on: Date.now(),
                updated_by_user_id: req.payLoad.id
            }, {
            where: {
                account_num: req.body.oldAccNumber
            }
        }
        )
        if (accountDetails[0] === 1) {
            await txnService.updateAcctIdTxnModel(req.body.oldAccNumber, req.body.newAccNumber)
            await txnService.updateAcctIdRecurTxnModel(req.body.oldAccNumber, req.body.newAccNumber)
            return res.status(200).send("Updated successfully")
        } else {
            return res.status(204).json()
        }
    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
}


// Close account
exports.deleteAccount = async (req, res) => {
    try {
        console.log("req.payLoad.id", req.payLoad.id)
        const adminDetails = await userModel.findOne({
            where: {
                id: req.payLoad.id,
                type_of_user: 'admin'
            }
        })
        if (!adminDetails) {
            return res.send(400).json()
        }

        let accountDetails = await userAccountModel.update(
            {
                account_status: 'Inactive',
                updated_on: Date.now(),
                updated_by_user_id: req.payLoad.id
            }, {
            where: {
                account_num: req.params.accountId
            }
        }
        )
        if (accountDetails[0] === 1) {
            return res.status(200).send()
        } else {
            return res.status(204).json()
        }

    } catch (e) {
        return res.status(500).send({ error: true, message: e.message });
    }
}