const Sequelize = require('sequelize')
const db = require('../database/dbConfig.js')

module.exports = db.sequelize.define(
    'txn',
    {
		id: {
			type: Sequelize.INTEGER(9),
			primaryKey: true,
			autoIncrement: true
		},
		from_acct_id: {
			type: Sequelize.STRING(70),
			required: true
		},
		to_acct_id: {
			type: Sequelize.STRING(70),
			required: true
		},
		type_of_transcation: {
            type: Sequelize.ENUM,
            values: ['Credit','Debit','Check','Fees'],
			required: true
		},
		amount: {
			type: Sequelize.DECIMAL,
			required: true
		},
		created_on: {
			type: Sequelize.DATE,
			defaultValue: Sequelize.NOW
        },
        description: {
            type: Sequelize.STRING(50),
            required: true
		},
		from_user_id: {
			type: Sequelize.INTEGER(9),
			required: true
		}
	},
	{
        timestamps: false,
        freezeTableName: true,
        tableName:"transactions"
	}
)