const Sequelize = require('sequelize')
const db = require('../database/dbConfig.js')

module.exports = db.sequelize.define(
	'user',
	{
		id: {
			type: Sequelize.INTEGER(9),
			primaryKey: true,
			autoIncrement: true
		},
		username: {
			type: Sequelize.STRING(50),
			required: true
		},
		email: {
			type: Sequelize.STRING(100),
			required: true
			//validate: { isEmail: true },
			//unique: true
		},
		password: {
			type: Sequelize.STRING(200),
			required: true
		},
		type_of_user: {
			type: Sequelize.ENUM,
			values: ['user', 'admin'],
			defaultValue: 'admin'
		},
		phone_num: {
			type: Sequelize.STRING(20),
			required: true
		},

		created_on: {
			type: Sequelize.DATE,
			defaultValue: Sequelize.NOW
		},
		created_by_user_id: {
			type: Sequelize.INTEGER(9)
		},
		updated_by_user_id: {
			type: Sequelize.INTEGER(9)
		}
	},
	{
		timestamps: false
	}
)