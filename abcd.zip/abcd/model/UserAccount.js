const Sequelize = require('sequelize')
const db = require('../database/dbConfig.js')

module.exports = db.sequelize.define(
	'user_account',
	{
		id: {
			type: Sequelize.INTEGER(9),
			primaryKey: true,
			autoIncrement: true
		},
		user_id: {
			type: Sequelize.INTEGER(9)
		},
		account_num: {
			type: Sequelize.STRING(70),
			required: true
		},
		type_of_account: {
			type: Sequelize.ENUM,
			values: ['Checking', 'Saving'],
			defaultValue: 'Checking'
		},
		account_status: {
			type: Sequelize.ENUM,
			values: ['Active', 'Inactive'],
			defaultValue: 'Active'
		},
		current_bal: {
			type: Sequelize.DECIMAL,
			required: true
			//validate: { isEmail: true },
			//unique: true
		},
		created_on: {
			type: Sequelize.DATE,
			defaultValue: Sequelize.NOW
		},
		created_by_user_id: {
			type: Sequelize.INTEGER(9)
		},
		updated_by_user_id: {
			type: Sequelize.INTEGER(9)
		}
	},
	{
		timestamps: false
	}
)