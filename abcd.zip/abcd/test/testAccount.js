var assert = require('chai').assert;
var app = require('../app');

var chai = require('chai');
chai.use(require('chai-http'));
var expect = require('chai').expect;

var agent = require('chai').request.agent(app);

// Create account
describe('Create account', function(){

    it('POST /account/addAccount',function(){
        
            return agent.post('/account/addAccount')
            .send({
                "userId": 3,
                "type_of_account": "Saving",
                "adminId": 1
            })
            .then(function(res){
                expect(200);
            });
    });
})

// Get accounts of the user
describe('Get accounts', function(){

    it('GET /account/:userId',function(){
        
            return agent.get('/account/3')
            .then(function(res){
                expect(200);
            });
    });
})

// Modify account number
describe('Modify account number', function(){

    it('POST /account/addAccount',function(){
        
            return agent.put('/users/addUser')
            .send({
                "oldAccNumber": "L5J392T54TU",
                "newAccNumber" : "98273812381",
                "adminId": 1
            })
            .then(function(res){
                expect(200);
            });
    });
})

// Delete account
describe('Delete account', function(){

    it('DELETE /account/:accountId',function(){
        
            return agent.delete('/account/98273812381')
            .then(function(res){
                expect(200);
            });
    });
})