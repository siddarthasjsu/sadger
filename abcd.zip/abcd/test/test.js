var assert = require('chai').assert;
var app = require('../app');

var chai = require('chai');
chai.use(require('chai-http'));
var expect = require('chai').expect;

var agent = require('chai').request.agent(app);

//User Login
describe('Grub Hub App', function(){

    it('POST /users/login',function(){
        
            return agent.post('/users/login')
            .send({"email":"narishtdhyani@gmail.com","password":"admin"})
            .then(function(res){
                expect(200);
            });
    });
})

//Add Admin
describe('Grub Hub App', function(){

    it('POST /users/addAdmin',function(){
        
            return agent.post('/users/addAdmin')
            .send({"email":"narishtdhyani2@gmail.com",
                    "password":"admin1",
                     "username":"Test Admin2",
                     "phone_num":"784484556"})
            .then(function(res){
                expect(200);
            });
    });
})

//Add User
describe('Grub Hub App', function(){

    it('POST /users/addUser',function(){
        
            return agent.post('/users/addUser')
            .send({"email":"user2@gmail.com",
                    "password":"admin",
                     "username":"Test User2",
                     "phone_num":"778787888",
                      "account_num":"789451268788994"
                    })
            .then(function(res){
                expect(200);
            });
    });
})

//Get Own Profile
describe('Grub Hub App', function(){

    it('GET /users/ownProfile',function(){
        
            return agent.get('/users/ownProfile')
            .set('Cookie', 'token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZV9vZl91c2VyIjoiYWRtaW4iLCJpYXQiOjE1NzMzNDA2MDQsImV4cCI6MTU3Mzk0MDYwNH0.Wq01X75p0dNUUXl9arahqKz3fzj3plRaJv3dJnWDQ6k')
            //.send({"email":"narishtdhyani@gmail.com","password":"admin"})
            .then(function(res){
                expect(200);
            });
    });
})

//Update Own Profile
describe('Grub Hub App', function(){

    it('PUT /users/ownProfile',function(){
        
            return agent.put('/users/ownProfile')
            .set('Cookie', 'token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZV9vZl91c2VyIjoiYWRtaW4iLCJpYXQiOjE1NzMzNDA2MDQsImV4cCI6MTU3Mzk0MDYwNH0.Wq01X75p0dNUUXl9arahqKz3fzj3plRaJv3dJnWDQ6k')
            .send({"email":"user2@gmail.com",
                     "username":"Test User2",
                     "phone_num":"897412555",
                    })
            .then(function(res){
                expect(res.body.error).to.equal(false);
            });
    });
})