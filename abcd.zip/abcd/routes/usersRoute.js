var express = require('express');
var router = express.Router();
var userController = require('../controller/UserController') ;
let middleware = require('../middleware/verifyToken');


//Register
router.post('/addAdmin',middleware.verifyToken, userController.addAdmin);

//Register
router.post('/addUser',middleware.verifyToken, userController.addUser);


//Login
router.post('/login', userController.login);

router.post('/logout',middleware.verifyToken, userController.logout);

//Own Profile
router.get('/ownProfile',middleware.verifyToken,userController.getOwnProfile);
router.put('/ownProfile',middleware.verifyToken, userController.editOwnProfile);

router.post('/oneTimeTransfer',userController.oneTimeTransfer);
router.post('/recurringTransfer',userController.recurringTransfer);
router.get('/viewAllTxns/:acctId/:id',userController.viewAllTxns);
router.post('/getTxnsByFilter',userController.getTxnsByFilter);
router.post('/oneTimeBillPayment',userController.oneTimeBillPayment);
router.post('/recurringBillPayments',userController.recurringBillPayments);
router.post('/addManualRefund',userController.addManualRefund);
router.get('/getRecurringTransfers/:acctId/:id',userController.getRecurringTransfers);
router.get('/getRecurringBillPayments/:acctId/:id',userController.getRecurringBillPayments);

module.exports = router;