var express = require('express');
var router = express.Router();
var accountController = require('../controller/AccountController');
let middleware = require('../middleware/verifyToken');


// Get accounts related to a particular user
router.get('/:userId', middleware.verifyToken, accountController.getAccount);

// Create checking or savings account for a user
router.post('/addAccount', middleware.verifyToken, accountController.addAccount);

// Modify account details
router.put('/addAccount', middleware.verifyToken, accountController.updateAccount);

// Close an account for a user
router.delete('/:accountId', middleware.verifyToken, accountController.deleteAccount);

module.exports = router;