const Sequelize = require('sequelize')
const dbConfig = {}
const sequelize = new Sequelize('banking_system', 'root', 'password', {
	//host: 'bankingapp.cqnqy2hypysb.us-east-2.rds.amazonaws.com',
	host:"localhost",
	dialect: 'mysql',
	operatorsAliases: false,

	pool: {
		max: 10,
		min: 0,
		acquire: 30000,
		idle: 10000
	}
})

dbConfig.sequelize = sequelize
dbConfig.Sequelize = Sequelize

module.exports = dbConfig